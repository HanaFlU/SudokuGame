﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPainter>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QMessageBox>
#include <QGroupBox>
#include <QIntValidator>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QDir>
#include <QCloseEvent> 

const int SIZE = 9;

class MainMenu;

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    enum class Mode { NewGame, Custom, Continue };

    explicit MainWindow(int modeValue, QWidget* parent = nullptr); // modeValue: 0=Custom, 1=Easy, 2=Medium, 3=Hard
    explicit MainWindow(Mode mode, QWidget* parent = nullptr); // Constructor for Continue mode
    ~MainWindow();

protected:
    void closeEvent(QCloseEvent* event) override;
        
signals:
    void gameClosed();  

private slots:
    void checkSolution(); // Renamed from handleCheck (if it existed) or added
    void giveHint();
    void showSolution();
    void resetBoard();
    void validateCustomBoard();
    void saveGame();
    void handleCellInput(int row, int col);
    void backToMenu();

private:
    int board[SIZE][SIZE] = { 0 };
    int solution[SIZE][SIZE] = { 0 };
    QLineEdit* cells[SIZE][SIZE];
    QPushButton* btnHint, * btnSolve, * btnReset, * btnBackMenu, * btnValidateCustom;
    QPushButton* btnSaveGame;
    QLabel* statusLabel;
    QGridLayout* gridLayout;
    QWidget* centralWidget;

    bool isCustomMode = false;
    bool gameInProgress = false; // Flag to track if changes were made / game is active
    QString saveFilePath;

    // Initialization modes
    int initialDifficulty = 2; // Default if modeValue constructor is used
    Mode currentMode;

    void setupUI();
    void updateBoardUI();
    QPushButton* createStyledButton(const QString& text);
    void generateNewGameInternal(int difficulty);
    void startCustomGameInternal();             
    void continueGameInternal();                

    // Custom game functions
    bool hasUniqueSolution(int customBoard[SIZE][SIZE]);
    void clearBoardForCustom(); 

    // Save/Load game functions
    // void saveGame(); // Slot now
    bool loadGame(); 
    bool hasSavedGame();
    QString getSaveFilePath(); // Helper

    // Sudoku logic functions (remain the same)
    bool isValid(int board[SIZE][SIZE], int row, int col, int num);
    bool generateFullBoard(int board[SIZE][SIZE], int row = 0, int col = 0);
    bool solveSudoku(int board[SIZE][SIZE], int row, int col, int& solutionCount);
    void removeNumbers(int board[SIZE][SIZE], int difficulty);
    void printBoard(int board[SIZE][SIZE]); // Keep for debugging
    bool isBoardCompleteAndCorrect(); // Helper to check win condition
};

#endif // MAINWINDOW_H
