﻿#include "mainwindow.h"
#include "mainmenu.h" 
#include <algorithm>
#include <random>
#include <vector>
#include <iostream>
#include <QMessageBox>
#include <QFileDialog>
#include <QStandardPaths>
#include <QDateTime>

bool MainWindow::isValid(int board[SIZE][SIZE], int row, int col, int num) {
    // Check row and column
    for (int i = 0; i < SIZE; i++) {
        if (board[row][i] == num && i != col) return false;
        if (board[i][col] == num && i != row) return false;
    }

    // Check 3x3 box
    int startRow = (row / 3) * 3, startCol = (col / 3) * 3;
    for (int i = startRow; i < startRow + 3; i++) {
        for (int j = startCol; j < startCol + 3; j++) {
            if (i == row && j == col) continue;
            if (board[i][j] == num) return false;
        }
    }
    return true;
}

bool MainWindow::generateFullBoard(int board[SIZE][SIZE], int row, int col) {
    if (row == SIZE) return true; // Base case: reached end of board

    int nextRow = row, nextCol = col + 1;
    if (nextCol == SIZE) {
        nextRow = row + 1;
        nextCol = 0;
    }

    // Skip already filled cells (shouldn't happen if called on empty board)
    if (board[row][col] != 0) return generateFullBoard(board, nextRow, nextCol);

    std::vector<int> numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(numbers.begin(), numbers.end(), g);

    for (int num : numbers) {
        if (isValid(board, row, col, num)) { 
            board[row][col] = num; 
            if (generateFullBoard(board, nextRow, nextCol)) {
                return true;
            }
            board[row][col] = 0; // Backtrack if recursion failed
        }
    }
    return false;
}


bool MainWindow::solveSudoku(int currentBoard[SIZE][SIZE], int row, int col, int& solutionCount) {
    // Find the next empty cell
    while (row < SIZE && currentBoard[row][col] != 0) {
        col++;
        if (col == SIZE) {
            row++;
            col = 0;
        }
    }

    // Base case: If no empty cell is found, a solution is reached
    if (row == SIZE) {
        solutionCount++;
        // If this is the first solution found, copy it to the member variable `solution`
        if (solutionCount == 1) {
            std::copy(¤tBoard[0][0], ¤tBoard[0][0] + SIZE * SIZE, &solution[0][0]);
        }
        // Stop searching if more than one solution is found when checking uniqueness
        return solutionCount <= 1;
    }


    // Try filling the current empty cell with numbers 1-9
    for (int num = 1; num <= SIZE; num++) {
        // Create a temporary board copy to check validity without modifying original rules check
        int tempBoardCheck[SIZE][SIZE];
        std::copy(¤tBoard[0][0], ¤tBoard[0][0] + SIZE * SIZE, &tempBoardCheck[0][0]);
        tempBoardCheck[row][col] = num; // Temporarily place the number

        bool placement_valid = true;
        // Check row
        for (int k = 0; k < SIZE; ++k) if (k != col && tempBoardCheck[row][k] == num) placement_valid = false;
        // Check col
        if (placement_valid) for (int k = 0; k < SIZE; ++k) if (k != row && tempBoardCheck[k][col] == num) placement_valid = false;
        // Check box
        if (placement_valid) {
            int startRow = (row / 3) * 3;
            int startCol = (col / 3) * 3;
            for (int i = startRow; i < startRow + 3; ++i) {
                for (int j = startCol; j < startCol + 3; ++j) {
                    if ((i != row || j != col) && tempBoardCheck[i][j] == num) placement_valid = false;
                }
            }
        }


        if (placement_valid) {
            currentBoard[row][col] = num; // Place the number

            // Recursively call solveSudoku for the next cell
            if (!solveSudoku(currentBoard, row, col, solutionCount)) {
                // If the recursive call returned false (more than 1 solution found), stop
                currentBoard[row][col] = 0; // Backtrack before returning false
                return false;
            }
            // If solutionCount is already > 1, we can stop early
            if (solutionCount > 1) {
                currentBoard[row][col] = 0; // Backtrack
                return false;
            }

            // If we are just looking for *a* solution (not counting), we could return true here.
            // But for counting, we need to continue exploring.
        }
    }

    // If no number from 1-9 works for the current cell, backtrack
    currentBoard[row][col] = 0;
    // Return true if we are still potentially on the path to the first solution or exactly one found
    // Return false if we have already found more than one solution
    return solutionCount <= 1;
}


void MainWindow::removeNumbers(int currentBoard[SIZE][SIZE], int difficulty) {
    int cellsToRemove;
    switch (difficulty) {
    case 1: cellsToRemove = 35; break; // Easy ~35-40
    case 2: cellsToRemove = 45; break; // Medium ~45-50
    case 3: cellsToRemove = 55; break; // Hard ~55+
    default: cellsToRemove = 45; break;
    }

    std::random_device rd;
    std::mt19937 g(rd());
    int removedCount = 0;
    int attempts = 0; // Prevent infinite loop if uniqueness is hard to maintain

    // Create a list of all cell coordinates
    std::vector<std::pair<int, int>> cellsList;
    for (int r = 0; r < SIZE; ++r) {
        for (int c = 0; c < SIZE; ++c) {
            cellsList.push_back({ r, c });
        }
    }
    std::shuffle(cellsList.begin(), cellsList.end(), g);


    for (const auto& cell : cellsList) {
        if (removedCount >= cellsToRemove) break;
        if (attempts > SIZE * SIZE * 2) break; // Safety break

        int row = cell.first;
        int col = cell.second;

        if (currentBoard[row][col] != 0) {
            int tempVal = currentBoard[row][col];
            currentBoard[row][col] = 0; // Try removing
            attempts++;

            // Check uniqueness
            int tempBoard[SIZE][SIZE];
            std::copy(¤tBoard[0][0], ¤tBoard[0][0] + SIZE * SIZE, &tempBoard[0][0]);
            int solutionCount = 0;
            solveSudoku(tempBoard, 0, 0, solutionCount);

            if (solutionCount != 1) {
                currentBoard[row][col] = tempVal; // Put it back if not unique
            }
            else {
                removedCount++; // Successfully removed
            }
        }
    }
    qDebug() << "Removed" << removedCount << "cells for difficulty" << difficulty;
}

void MainWindow::printBoard(int pBoard[SIZE][SIZE]) { // Renamed param to avoid shadowing
    qDebug() << "Current Board State:";
    for (int i = 0; i < SIZE; i++) {
        QString rowStr = "";
        for (int j = 0; j < SIZE; j++) {
            rowStr += QString::number(pBoard[i][j]) + " ";
        }
        qDebug() << rowStr;
    }
    qDebug() << "======================";
}
// --- End of Sudoku Logic ---

// Constructor for New Game / Custom
MainWindow::MainWindow(int modeValue, QWidget* parent) : QMainWindow(parent) {
    currentMode = (modeValue == 0) ? Mode::Custom : Mode::NewGame;
    initialDifficulty = (modeValue >= 1 && modeValue <= 3) ? modeValue : 2; // Default to medium if invalid
    isCustomMode = (currentMode == Mode::Custom);

    saveFilePath = getSaveFilePath();
    setupUI();

    if (currentMode == Mode::NewGame) {
        generateNewGameInternal(initialDifficulty);
    }
    else { // Custom mode
        startCustomGameInternal();
    }
}

// Constructor for Continue Game
MainWindow::MainWindow(Mode mode, QWidget* parent) : QMainWindow(parent) {
    Q_ASSERT(mode == Mode::Continue); // Ensure this constructor is used correctly
    currentMode = Mode::Continue;
    isCustomMode = false; // Cannot continue a custom setup

    saveFilePath = getSaveFilePath();
    setupUI();
    continueGameInternal(); // Load the saved game
}


MainWindow::~MainWindow() {
    qDebug() << "MainWindow destroyed";
}

QString MainWindow::getSaveFilePath() {
    QString appDataPath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir dir(appDataPath);
    if (!dir.exists()) {
        dir.mkpath(".");
    }
    return appDataPath + "/sudoku_save.json";
}

bool MainWindow::hasSavedGame() {
    QFile file(saveFilePath);
    return file.exists() && file.size() > 0;
}


void MainWindow::setupUI() {
    setWindowTitle("Sudoku");
    centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);

    // More classic / simpler stylesheet
    setStyleSheet(R"(
        QMainWindow {
            background-color: #f0eadd; /* Lighter parchment/beige */
        }
        QWidget#centralWidget { /* Target central widget specifically */
             background-color: #f0eadd;
        }
        QGroupBox {
            font-family: "Garamond", serif;
            font-size: 16px;
            font-weight: bold;
            color: #5a4d41; /* Dark brown */
            border: 1px solid #d3c5b4; /* Lighter border */
            margin-top: 1ex;
             background-color: #e6dbc8; /* Slightly darker groupbox */
             padding: 15px; /* Add padding inside groupbox */
             border-radius: 0px; /* Sharp corners */
        }
         QGroupBox::title {
             subcontrol-origin: margin;
             subcontrol-position: top left;
             padding: 0 3px;
             left: 10px; /* Adjust title position */
              background-color: #e6dbc8; /* Match groupbox background */
         }

        QLineEdit {
            background-color: #ffffff; /* White cells */
            border: 1px solid #cccccc; /* Lighter gray border */
            font-size: 20px; /* Larger font for numbers */
            font-weight: bold;
            color: #333333; /* Dark gray text */
            border-radius: 0px; /* Sharp corners */
            min-width: 30px; /* Ensure minimum size */
            min-height: 30px;
        }
         /* Style for the read-only cells (original puzzle numbers) */
        QLineEdit[readOnly="true"] {
            background-color: #f5f5f5; /* Very light gray */
            color: #222222; /* Black for given numbers */
            font-weight: bold;
        }
        /* Style for editable cells when they have correct input (optional) */
         QLineEdit.correct {
             background-color: #e0ffe0; /* Light green for correct */
             color: #006400; /* Dark green text */
         }
         /* Style for editable cells when they have incorrect input */
         QLineEdit.incorrect {
             background-color: #ffe0e0; /* Light red for incorrect */
             color: #a00000; /* Dark red text */
         }


        QPushButton {
            background-color: #d2b48c; /* Tan */
            color: #4b3832; /* Dark brown text */
            border: 1px solid #8b7e66;
            padding: 8px 12px;
            border-radius: 3px; /* Slightly rounded */
            font-family: "Garamond", serif;
            font-size: 14px;
             min-width: 100px; /* Button width */
        }
        QPushButton:hover {
            background-color: #c1a37c;
        }
        QPushButton:pressed {
            background-color: #a08a6c;
        }
         QPushButton:disabled {
             background-color: #e0d8cd;
             color: #888888;
             border-color: #c0b8ae;
         }

        QLabel#statusLabel { /* Specific label */
            font-size: 14px;
            color: #4b3832;
            font-family: "Garamond", serif;
            font-weight: bold;
            margin-top: 10px;
            background-color: #e6dbc8; /* Match groupbox bg */
            padding: 5px;
            border: 1px solid #d3c5b4;
        }
        QFrame#blockFrame { /* Style the 3x3 block separators */
             border: 2px solid #5a4d41; /* Thicker dark brown border */
             border-radius: 0px;
             background-color: transparent;
         }
         QFrame#sudokuFrame { /* Style the outer frame of the grid */
             border: 3px solid #3a2d21; /* Even thicker border */
             background-color: #f0eadd; /* Match main background */
             padding: 3px; /* Padding around the grid */
         }


    )");

    centralWidget->setObjectName("centralWidget");

    QHBoxLayout* mainLayout = new QHBoxLayout(centralWidget); // Layout for the central widget
    mainLayout->setSpacing(20); // Space between grid and controls

    // --- Sudoku Grid Setup ---
    QFrame* sudokuFrame = new QFrame(); // Use a QFrame for outer border
    sudokuFrame->setObjectName("sudokuFrame");
    QVBoxLayout* sudokuFrameLayout = new QVBoxLayout(sudokuFrame); // Layout inside the frame

    QGridLayout* mainGridLayout = new QGridLayout;
    mainGridLayout->setSpacing(0); // No spacing between blocks
    mainGridLayout->setContentsMargins(0, 0, 0, 0); // No margins for the main grid layout

    for (int blockRow = 0; blockRow < 3; ++blockRow) {
        for (int blockCol = 0; blockCol < 3; ++blockCol) {
            QFrame* blockFrame = new QFrame();
            blockFrame->setObjectName("blockFrame"); // Use object name for specific styling
            blockFrame->setFrameShape(QFrame::Box); // Can also use shape/shadow
            // blockFrame->setLineWidth(1); // Set line width if using shape/shadow

            QGridLayout* blockLayout = new QGridLayout(blockFrame);
            blockLayout->setSpacing(1); // Minimal spacing between cells within a block
            blockLayout->setContentsMargins(1, 1, 1, 1); // Minimal margins

            for (int row = 0; row < 3; ++row) {
                for (int col = 0; col < 3; ++col) {
                    int globalRow = blockRow * 3 + row;
                    int globalCol = blockCol * 3 + col;

                    cells[globalRow][globalCol] = new QLineEdit(this);
                    cells[globalRow][globalCol]->setAlignment(Qt::AlignCenter);
                    cells[globalRow][globalCol]->setMaxLength(1);
                    cells[globalRow][globalCol]->setFixedSize(40, 40); // Adjust size as needed


                    QIntValidator* validator = new QIntValidator(1, 9, this);
                    cells[globalRow][globalCol]->setValidator(validator);

                    // Connect textChanged signal
                    connect(cells[globalRow][globalCol], &QLineEdit::textChanged, this, [this, globalRow, globalCol](const QString& text) {
                        handleCellInput(globalRow, globalCol);
                        });


                    blockLayout->addWidget(cells[globalRow][globalCol], row, col);
                }
            }
            mainGridLayout->addWidget(blockFrame, blockRow, blockCol);
        }
    }
    sudokuFrameLayout->addLayout(mainGridLayout); // Add the grid of blocks to the frame layout
    // --- End Sudoku Grid Setup ---


    // --- Control Panel Setup ---
    QGroupBox* controlFrame = new QGroupBox("Controls");
    QVBoxLayout* controlLayout = new QVBoxLayout;
    controlLayout->setSpacing(10); // Spacing between controls

    btnValidateCustom = createStyledButton("Validate & Play");
    btnHint = createStyledButton("Hint");
    btnSolve = createStyledButton("Show Solution");
    btnReset = createStyledButton("Reset Board");
    btnSaveGame = createStyledButton("Save Game");
    btnBackMenu = createStyledButton("Back to Menu");


    controlLayout->addWidget(btnValidateCustom); // Initially hidden if not in custom mode
    controlLayout->addWidget(btnHint);
    controlLayout->addWidget(btnSolve);
    controlLayout->addWidget(btnReset);
    controlLayout->addWidget(btnSaveGame);
    controlLayout->addStretch(1); // Pushes Back button down
    controlLayout->addWidget(btnBackMenu);


    statusLabel = new QLabel("Welcome to Sudoku!");
    statusLabel->setObjectName("statusLabel");
    statusLabel->setAlignment(Qt::AlignCenter);
    statusLabel->setWordWrap(true);
    controlLayout->addWidget(statusLabel);


    controlFrame->setLayout(controlLayout);
    // --- End Control Panel Setup ---

    // Add grid and controls to the main layout
    mainLayout->addWidget(sudokuFrame, 3); // Give grid more stretch factor
    mainLayout->addWidget(controlFrame, 1);

    // Set initial visibility/enabled state based on mode
    btnValidateCustom->setVisible(isCustomMode);
    btnHint->setEnabled(!isCustomMode);
    btnSolve->setEnabled(!isCustomMode);
    btnSaveGame->setEnabled(!isCustomMode); // Can only save generated/loaded games


    // Connect button signals to slots
    connect(btnHint, &QPushButton::clicked, this, &MainWindow::giveHint);
    connect(btnReset, &QPushButton::clicked, this, &MainWindow::resetBoard);
    connect(btnSolve, &QPushButton::clicked, this, &MainWindow::showSolution);
    connect(btnValidateCustom, &QPushButton::clicked, this, &MainWindow::validateCustomBoard);
    connect(btnSaveGame, &QPushButton::clicked, this, &MainWindow::saveGame);
    connect(btnBackMenu, &QPushButton::clicked, this, &MainWindow::backToMenu);

}


QPushButton* MainWindow::createStyledButton(const QString& text) {
    QPushButton* btn = new QPushButton(text);
    // Icons can be added here if needed: btn->setIcon(QIcon(":/path/to/icon.png"));
    return btn;
}

void MainWindow::updateBoardUI() {
    gameInProgress = false; // Reset flag until user makes a move
    for (int row = 0; row < SIZE; row++) {
        for (int col = 0; col < SIZE; col++) {
            cells[row][col]->setProperty("class", ""); // Clear custom classes
            if (board[row][col] == 0) {
                cells[row][col]->setText("");
                cells[row][col]->setReadOnly(false);
                cells[row][col]->setStyleSheet(""); // Reset specific style
            }
            else {
                cells[row][col]->setText(QString::number(board[row][col]));
                cells[row][col]->setReadOnly(true);
                // Apply readOnly style from the main stylesheet automatically
                cells[row][col]->setStyleSheet(""); // Reset specific style before main style applies
            }
            // Ensure validator is present
            if (!cells[row][col]->validator()) {
                cells[row][col]->setValidator(new QIntValidator(1, 9, cells[row][col]));
            }
        }
    }
    // Re-apply the global stylesheet to ensure base styles are set correctly
    qApp->setStyleSheet(styleSheet());
}


// Initialize a new game
void MainWindow::generateNewGameInternal(int difficulty) {
    isCustomMode = false;
    gameInProgress = false; // New game starts fresh
    qDebug() << "Generating new game with difficulty:" << difficulty;

    // Clear boards
    for (int i = 0; i < SIZE; ++i) for (int j = 0; j < SIZE; ++j) board[i][j] = solution[i][j] = 0;

    // Generate a full solution
    if (!generateFullBoard(solution)) {
        QMessageBox::critical(this, "Error", "Failed to generate a full Sudoku board.");
        // Handle error case, maybe show menu again or exit?
        backToMenu(); // Go back to menu on generation failure
        return;
    }
    qDebug() << "Full solution generated.";
    // printBoard(solution); // Debug: print solution

   // Copy solution to board and remove numbers
    std::copy(&solution[0][0], &solution[0][0] + SIZE * SIZE, &board[0][0]);
    removeNumbers(board, difficulty);
    qDebug() << "Numbers removed.";
    // printBoard(board); // Debug: print starting board

    // Update UI
    updateBoardUI();

    // Update controls state
    btnValidateCustom->setVisible(false);
    btnHint->setEnabled(true);
    btnSolve->setEnabled(true);
    btnSaveGame->setEnabled(true); // Can save a new game

    QString difficultyText;
    switch (difficulty) {
    case 1: difficultyText = "Easy"; break;
    case 2: difficultyText = "Medium"; break;
    case 3: difficultyText = "Hard"; break;
    default: difficultyText = "Unknown"; break;
    }
    statusLabel->setText("New " + difficultyText + " game started. Fill the empty cells!");
}

// Initialize custom game mode
void MainWindow::startCustomGameInternal() {
    isCustomMode = true;
    gameInProgress = false; // No progress yet
    qDebug() << "Starting custom game setup.";

    clearBoardForCustom(); // Clear internal boards

    // Make all cells editable and clear UI
    for (int row = 0; row < SIZE; row++) {
        for (int col = 0; col < SIZE; col++) {
            cells[row][col]->setText("");
            cells[row][col]->setReadOnly(false);
            cells[row][col]->setStyleSheet(""); // Reset styles
            cells[row][col]->setProperty("class", ""); // Clear custom classes
            // Ensure validator is present
            if (!cells[row][col]->validator()) {
                cells[row][col]->setValidator(new QIntValidator(1, 9, cells[row][col]));
            }
        }
    }
    qApp->setStyleSheet(styleSheet()); // Re-apply global style sheet

    // Update controls state
    btnValidateCustom->setVisible(true);
    btnHint->setEnabled(false);
    btnSolve->setEnabled(false);
    btnSaveGame->setEnabled(false); // Can't save until validated

    statusLabel->setText("Custom Mode: Enter your puzzle numbers, then click 'Validate & Play'.");
}

// Load a saved game
void MainWindow::continueGameInternal() {
    isCustomMode = false; // Loaded games are never custom mode
    gameInProgress = false; // Will be set true if user makes changes later
    qDebug() << "Attempting to continue saved game.";

    if (!loadGame()) {
        QMessageBox::warning(this, "Load Error", "Could not load the saved game. Starting a new Medium game.");
        // Fallback: start a new medium game if load fails
        generateNewGameInternal(2);
        return;
    }

    // Update UI based on loaded 'board' and 'userInputs' (which are now merged in loadGame)
    updateBoardUI(); // Sets read-only based on loaded 'board'

    // Now load user inputs from the file into the UI cells
    QFile file(saveFilePath);
    if (!file.open(QIODevice::ReadOnly)) { /* Error already handled in loadGame */ return; }
    QByteArray data = file.readAll();
    file.close();
    QJsonDocument doc = QJsonDocument::fromJson(data);
    QJsonObject gameState = doc.object();

    if (gameState.contains("userInputs")) {
        QJsonArray userInputsArray = gameState["userInputs"].toArray();
        for (int row = 0; row < SIZE; row++) {
            if (row < userInputsArray.size()) {
                QJsonArray rowArray = userInputsArray[row].toArray();
                for (int col = 0; col < SIZE; col++) {
                    if (col < rowArray.size()) {
                        int value = rowArray[col].toInt();
                        // Only set text if the cell is supposed to be empty (not part of original puzzle)
                        // and the loaded value is not 0
                        if (board[row][col] == 0 && value != 0) {
                            cells[row][col]->setText(QString::number(value));
                            // handleCellInput will be triggered by setText to validate/style
                        }
                        else if (board[row][col] == 0 && value == 0) {
                            cells[row][col]->setText(""); // Ensure empty if saved as 0
                        }
                    }
                }
            }
        }
    }


    // Update controls state
    btnValidateCustom->setVisible(false);
    btnHint->setEnabled(true);
    btnSolve->setEnabled(true);
    btnSaveGame->setEnabled(true);

    statusLabel->setText("Game loaded successfully. Continue playing!");
}


// Clear the board arrays
void MainWindow::clearBoardForCustom() {
    for (int row = 0; row < SIZE; row++) {
        for (int col = 0; col < SIZE; col++) {
            board[row][col] = 0;
            solution[row][col] = 0;
        }
    }
}

// Validate custom board input
void MainWindow::validateCustomBoard() {
    qDebug() << "Validating custom board...";
    int customBoard[SIZE][SIZE] = { 0 };
    bool hasInput = false;

    // 1. Read the current board state from UI into customBoard
    for (int row = 0; row < SIZE; row++) {
        for (int col = 0; col < SIZE; col++) {
            QString text = cells[row][col]->text();
            if (!text.isEmpty()) {
                bool ok;
                int val = text.toInt(&ok);
                if (ok && val >= 1 && val <= 9) {
                    customBoard[row][col] = val;
                    hasInput = true;
                }
                else {
                    QMessageBox::warning(this, "Invalid Input", QString("Invalid value '%1' at row %2, col %3. Please use numbers 1-9.").arg(text).arg(row + 1).arg(col + 1));
                    return; // Stop validation
                }
            }
        }
    }

    if (!hasInput) {
        QMessageBox::warning(this, "Empty Board", "Please enter some numbers for the puzzle.");
        return;
    }


    // 2. Check if the initial board is valid (no immediate conflicts)
    for (int row = 0; row < SIZE; row++) {
        for (int col = 0; col < SIZE; col++) {
            int num = customBoard[row][col];
            if (num != 0) {
                // Temporarily set to 0 ONLY for the validity check of its own placement rules
                int originalValue = customBoard[row][col];
                customBoard[row][col] = 0;
                bool placementValid = isValid(customBoard, row, col, originalValue);
                customBoard[row][col] = originalValue; // Restore immediately


                if (!placementValid) {
                    QMessageBox::warning(this, "Invalid Board",
                        QString("The initial board has conflicts. Check the number at row %1, col %2.").arg(row + 1).arg(col + 1));
                    qDebug() << "Conflict found at" << row << col << "with value" << num;
                    return;
                }
            }
        }
    }
    qDebug() << "Initial board conflicts check passed.";


    // 3. Check if the board has a unique solution
    if (!hasUniqueSolution(customBoard)) {
        QMessageBox::warning(this, "Invalid Board",
            "This puzzle does not have a unique solution. Please add or change numbers.");
        qDebug() << "Unique solution check failed.";
        return;
    }
    qDebug() << "Unique solution check passed.";


    // 4. If validation passes:
    // Copy the custom board to the game board 'board'
    std::copy(&customBoard[0][0], &customBoard[0][0] + SIZE * SIZE, &board[0][0]);

    // The solution should have been stored in 'solution' member by hasUniqueSolution
    // (Make sure solveSudoku saves the first solution found)

    // Update UI: Mark given numbers as read-only, clear others
    updateBoardUI(); // This handles setting read-only and clearing empty cells

    // Switch back to play mode
    isCustomMode = false;
    gameInProgress = false; // Start of the playable game
    btnValidateCustom->setVisible(false);
    btnHint->setEnabled(true);
    btnSolve->setEnabled(true);
    btnSaveGame->setEnabled(true); // Allow saving custom game once validated

    statusLabel->setText("Custom game validated! You can now play.");
    qDebug() << "Custom game validated and ready to play.";
}


// Check if the board has a unique solution
bool MainWindow::hasUniqueSolution(int customBoard[SIZE][SIZE]) {
    int tempBoard[SIZE][SIZE];
    std::copy(&customBoard[0][0], &customBoard[0][0] + SIZE * SIZE, &tempBoard[0][0]);

    int solutionCount = 0;
    solveSudoku(tempBoard, 0, 0, solutionCount); // solveSudoku should fill 'this->solution' on first find

    qDebug() << "Found" << solutionCount << "solutions.";
    return solutionCount == 1;
}

// Give a hint
void MainWindow::giveHint() {
    if (isCustomMode) return; // Should be disabled anyway

    std::vector<std::pair<int, int>> emptyEditableCells;
    for (int row = 0; row < SIZE; row++) {
        for (int col = 0; col < SIZE; col++) {
            // Hint for cells that are part of the puzzle to solve AND are currently empty
            if (board[row][col] == 0 && cells[row][col]->text().isEmpty()) {
                emptyEditableCells.emplace_back(row, col);
            }
        }
    }

    if (!emptyEditableCells.empty()) {
        std::random_device rd;
        std::mt19937 g(rd());
        std::shuffle(emptyEditableCells.begin(), emptyEditableCells.end(), g);

        auto [row, col] = emptyEditableCells.front();
        cells[row][col]->setText(QString::number(solution[row][col]));
        // handleCellInput will color it correctly
        statusLabel->setText(QString("Hint: Cell (%1, %2) is %3").arg(row + 1).arg(col + 1).arg(solution[row][col]));
        gameInProgress = true; // Giving a hint counts as progress
    }
    else {
        // Check if the board is full but incorrect
        bool full = true;
        for (int r = 0; r < SIZE; ++r) for (int c = 0; c < SIZE; ++c) if (cells[r][c]->text().isEmpty()) full = false;

        if (full) {
            statusLabel->setText("Board is full. Check your answers or reset.");
        }
        else {
            statusLabel->setText("No more empty cells to give hints for!");
        }
    }
}

// Show the complete solution
void MainWindow::showSolution() {
    if (isCustomMode) return; // Should be disabled anyway

    // Check if solution exists (it should if game started correctly)
    if (solution[0][0] == 0 && !solveSudoku(board, 0, 0, *(new int(0)))) { // Try to solve if solution is missing
        QMessageBox::warning(this, "Solution Error", "Could not find the solution for the current board.");
        return;
    }


    for (int row = 0; row < SIZE; row++) {
        for (int col = 0; col < SIZE; col++) {
            cells[row][col]->setProperty("class", ""); // Clear classes
            cells[row][col]->setText(QString::number(solution[row][col]));
            cells[row][col]->setReadOnly(true); // Make all read-only when showing solution
            cells[row][col]->setStyleSheet(""); // Reset specific style
        }
    }
    qApp->setStyleSheet(styleSheet()); // Re-apply global stylesheet

    statusLabel->setText("Showing the solution. Start a new game to play again.");
    gameInProgress = false; // Game is over, no longer 'in progress' for saving purposes
    btnHint->setEnabled(false);
    btnSaveGame->setEnabled(false); // Don't save a solved board
    btnReset->setEnabled(false); // Reset doesn't make sense on solved board
}

// Reset the board to its initial state (or clear custom)
void MainWindow::resetBoard() {
    qDebug() << "Resetting board. Custom mode:" << isCustomMode;
    if (isCustomMode) {
        // In custom mode setup, clear all editable cells
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                cells[row][col]->setText("");
                cells[row][col]->setProperty("class", "");
                cells[row][col]->setStyleSheet("");
            }
        }
        qApp->setStyleSheet(styleSheet());
        statusLabel->setText("Custom board input cleared.");
    }
    else {
        // In play mode, reset only the user-entered cells
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                // If the cell was originally empty (from `board`), clear it
                if (board[row][col] == 0) {
                    cells[row][col]->setText("");
                    cells[row][col]->setProperty("class", "");
                    cells[row][col]->setStyleSheet("");
                }
            }
        }
        qApp->setStyleSheet(styleSheet());
        statusLabel->setText("Board reset to initial state.");
        gameInProgress = false; // Resetting removes progress
    }
}

// Handle user input in a cell
void MainWindow::handleCellInput(int row, int col) {
    // Ignore changes if the cell is read-only (part of original puzzle)
    if (cells[row][col]->isReadOnly()) {
        return;
    }

    gameInProgress = true; // User made a change
    QString text = cells[row][col]->text();
    cells[row][col]->setProperty("class", ""); // Clear previous status class
    cells[row][col]->setStyleSheet(""); // Clear specific inline style


    if (text.isEmpty()) {
        // Cell cleared, reset style (handled by clearing class/style above)
        return;
    }

    bool ok;
    int userInput = text.toInt(&ok);

    // Basic validation (1-9) - validator should handle this, but double-check
    if (!ok || userInput < 1 || userInput > 9) {
        cells[row][col]->setProperty("class", "incorrect"); // Mark as incorrect input type
        // Reapply stylesheet to reflect the class change
        qApp->setStyleSheet(styleSheet());
        statusLabel->setText("Invalid input. Use numbers 1-9.");
        return;
    }

    // Check for conflicts with other visible numbers (read-only or user-entered)
    bool conflict = false;
    // Check row
    for (int c = 0; c < SIZE; ++c) {
        if (c != col && cells[row][c]->text() == text) {
            conflict = true;
            break;
        }
    }
    // Check column
    if (!conflict) {
        for (int r = 0; r < SIZE; ++r) {
            if (r != row && cells[r][col]->text() == text) {
                conflict = true;
                break;
            }
        }
    }
    // Check 3x3 block
    if (!conflict) {
        int startRow = (row / 3) * 3;
        int startCol = (col / 3) * 3;
        for (int r = startRow; r < startRow + 3; ++r) {
            for (int c = startCol; c < startCol + 3; ++c) {
                if ((r != row || c != col) && cells[r][c]->text() == text) {
                    conflict = true;
                    break;
                }
            }
            if (conflict) break;
        }
    }


    // Style based on conflict or correctness against solution (if not in custom setup mode)
    if (conflict) {
        cells[row][col]->setProperty("class", "incorrect");
        statusLabel->setText("Number conflicts with another cell.");
    }
    else if (!isCustomMode && solution[row][col] != 0) { // Only check solution if game is running
        if (userInput == solution[row][col]) {
            cells[row][col]->setProperty("class", "correct");
            // Check for win condition when a correct number is placed
            if (isBoardCompleteAndCorrect()) {
                QMessageBox::information(this, "Congratulations!", "You solved the puzzle!");
                gameInProgress = false; // Game finished
                // Optionally disable further input or saving
                btnSaveGame->setEnabled(false);
                btnHint->setEnabled(false);
            }
            else {
                statusLabel->setText("Correct!");
            }
        }
        else {
            cells[row][col]->setProperty("class", "incorrect");
            statusLabel->setText("Incorrect number for this cell.");
        }
    }
    else if (isCustomMode) {
        // In custom mode setup, just clear status if no conflict
        statusLabel->setText("Enter puzzle numbers or Validate.");
    }
    else {
        // No conflict, but solution check not applicable (e.g., if solution wasn't generated?)
        statusLabel->setText("Number placed (no conflicts).");
    }


    // Reapply the stylesheet to make the QLineEdit update its appearance based on the set property
    // This is a common way to dynamically style widgets based on state
    cells[row][col]->style()->unpolish(cells[row][col]);
    cells[row][col]->style()->polish(cells[row][col]);
    cells[row][col]->update();
    // Or potentially re-apply the whole app's stylesheet if properties affect many things
    // qApp->setStyleSheet(styleSheet());

}


// Check if the board is full and all numbers match the solution
bool MainWindow::isBoardCompleteAndCorrect() {
    if (isCustomMode) return false; // Not applicable during setup

    for (int row = 0; row < SIZE; ++row) {
        for (int col = 0; col < SIZE; ++col) {
            QString text = cells[row][col]->text();
            if (text.isEmpty()) {
                return false; // Not full
            }
            bool ok;
            int val = text.toInt(&ok);
            if (!ok || val != solution[row][col]) {
                return false; // Incorrect number or invalid text
            }
        }
    }
    return true; // Board is full and correct
}


// Save game state
void MainWindow::saveGame() {
    if (isCustomMode || !gameInProgress) {
        statusLabel->setText("Cannot save in custom setup or when no changes made.");
        qDebug() << "Save aborted. isCustomMode:" << isCustomMode << "gameInProgress:" << gameInProgress;
        return;
    }

    qDebug() << "Saving game...";
    QJsonObject gameState;

    // Save original puzzle state (board)
    QJsonArray boardArray;
    for (int row = 0; row < SIZE; row++) {
        QJsonArray rowArray;
        for (int col = 0; col < SIZE; col++) {
            rowArray.append(board[row][col]); // Save the initial puzzle numbers
        }
        boardArray.append(rowArray);
    }
    gameState["board"] = boardArray;

    // Save solution
    QJsonArray solutionArray;
    for (int row = 0; row < SIZE; row++) {
        QJsonArray rowArray;
        for (int col = 0; col < SIZE; col++) {
            rowArray.append(solution[row][col]);
        }
        solutionArray.append(rowArray);
    }
    gameState["solution"] = solutionArray;

    // Save current user inputs (only for non-readonly cells)
    QJsonArray userInputsArray;
    for (int row = 0; row < SIZE; row++) {
        QJsonArray rowArray;
        for (int col = 0; col < SIZE; col++) {
            int value = 0; // Default to 0 (empty)
            if (!cells[row][col]->isReadOnly()) { // Only save input for editable cells
                QString text = cells[row][col]->text();
                if (!text.isEmpty()) {
                    bool ok;
                    value = text.toInt(&ok);
                    if (!ok) value = 0; // Save 0 if input is invalid somehow
                }
            }
            rowArray.append(value); // Append 0 for readonly cells or empty editable cells
        }
        userInputsArray.append(rowArray);
    }
    gameState["userInputs"] = userInputsArray;

    // Save timestamp
    gameState["timestamp"] = QDateTime::currentDateTime().toString(Qt::ISODate);

    // Save to file
    QJsonDocument doc(gameState);
    QFile file(saveFilePath);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(doc.toJson());
        file.close();
        statusLabel->setText("Game saved successfully!");
        qDebug() << "Game saved to" << saveFilePath;
        gameInProgress = false; // Mark as saved (no unsaved progress)
    }
    else {
        QMessageBox::warning(this, "Save Error", "Could not save the game state.");
        qDebug() << "Error saving game to" << saveFilePath << ":" << file.errorString();
    }
}

// Load game state from file (used by continueGameInternal)
bool MainWindow::loadGame() {
    if (!hasSavedGame()) {
        qDebug() << "No saved game file found at" << saveFilePath;
        return false;
    }

    QFile file(saveFilePath);
    if (!file.open(QIODevice::ReadOnly)) {
        qDebug() << "Could not open saved game file:" << file.errorString();
        return false;
    }

    QByteArray data = file.readAll();
    file.close();

    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (doc.isNull() || !doc.isObject()) {
        qDebug() << "Invalid JSON format in save file.";
        return false;
    }

    QJsonObject gameState = doc.object();

    // Load board state (original puzzle)
    if (gameState.contains("board") && gameState["board"].isArray()) {
        QJsonArray boardArray = gameState["board"].toArray();
        if (boardArray.size() == SIZE) {
            for (int row = 0; row < SIZE; row++) {
                if (boardArray[row].isArray() && boardArray[row].toArray().size() == SIZE) {
                    QJsonArray rowArray = boardArray[row].toArray();
                    for (int col = 0; col < SIZE; col++) {
                        board[row][col] = rowArray[col].toInt(0); // Default to 0 if invalid
                    }
                }
                else { qDebug() << "Invalid row array size in saved board"; return false; }
            }
        }
        else { qDebug() << "Invalid board array size in save file"; return false; }
    }
    else { qDebug() << "Missing or invalid 'board' array in save file"; return false; }


    // Load solution
    if (gameState.contains("solution") && gameState["solution"].isArray()) {
        QJsonArray solutionArray = gameState["solution"].toArray();
        if (solutionArray.size() == SIZE) {
            for (int row = 0; row < SIZE; row++) {
                if (solutionArray[row].isArray() && solutionArray[row].toArray().size() == SIZE) {
                    QJsonArray rowArray = solutionArray[row].toArray();
                    for (int col = 0; col < SIZE; col++) {
                        solution[row][col] = rowArray[col].toInt(0);
                    }
                }
                else { qDebug() << "Invalid row array size in saved solution"; return false; }
            }
        }
        else { qDebug() << "Invalid solution array size in save file"; return false; }
    }
    else { qDebug() << "Missing or invalid 'solution' array in save file"; return false; }


    // User inputs are loaded separately into the UI in continueGameInternal after updateBoardUI sets read-only status

    qDebug() << "Game data loaded successfully from" << saveFilePath;
    return true;
}


// Handle window close event
void MainWindow::closeEvent(QCloseEvent* event) {
    qDebug() << "Close event triggered. gameInProgress:" << gameInProgress;
    if (gameInProgress && !isCustomMode) { // Only ask if changes were made in a playable game
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(this, "Exit Game", "Do you want to save your progress before exiting?",
            QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);

        if (reply == QMessageBox::Save) {
            saveGame(); // Attempt to save
            // Check if save was successful? For now, assume it works or user saw error.
            event->accept(); // Close window
        }
        else if (reply == QMessageBox::Discard) {
            event->accept(); // Close window without saving
        }
        else { // Cancel
            event->ignore(); // Don't close window
            return; // Exit the function early
        }
    }
    else {
        event->accept(); // No changes or in custom mode, just close
    }

    // If accepted, optionally signal the main menu to reappear
    // emit gameClosed(); // Requires signal definition in .h and connection in mainmenu.cpp
     // Instead of signal, let's manage window visibility in mainmenu.cpp directly
     // Find the main menu instance (this is tricky, better handled by main flow)
     // For simplicity, closing the game window will just exit if not handled by mainmenu

}

// Slot for Back to Menu button
void MainWindow::backToMenu() {
    qDebug() << "Back to menu clicked. gameInProgress:" << gameInProgress;
    if (gameInProgress && !isCustomMode) { // Ask to save if progress exists
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(this, "Return to Menu", "Do you want to save your progress before returning to the menu?",
            QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);

        if (reply == QMessageBox::Save) {
            saveGame();
            // Proceed to close regardless of save success for now
        }
        else if (reply == QMessageBox::Cancel) {
            return; // Don't go back to menu
        }
        // If Discard or Save, proceed to close this window
    }

    // Find and show the MainMenu window
    // This requires a way to access the MainMenu instance.
    // A simple approach is to iterate through top-level widgets.
    QWidget* menu = nullptr;
    for (QWidget* widget : QApplication::topLevelWidgets()) {
        if (qobject_cast<MainMenu*>(widget)) {
            menu = widget;
            break;
        }
    }

    this->close(); // Close the current game window (closeEvent logic handles saving)

    if (menu) {
        // Update the continue button state on the menu before showing it
        MainMenu* mainMenuPtr = qobject_cast<MainMenu*>(menu);
        if (mainMenuPtr) {
            // Need a public method in MainMenu to update button state, e.g., mainMenuPtr->updateContinueButton();
            // For now, assume it will check when shown or handle it there.
        }
        menu->show();
    }
    else {
        qDebug() << "Could not find MainMenu window to return to.";
        // As a fallback, maybe create a new menu? Or just exit?
        // For now, closing the window might lead to app exit if menu wasn't found/handled.
    }
}